# Fader & Frame — Starter
This package includes:
- `logo.svg` — Concept A monogram (SVG)
- `index.html` — Single-file responsive one-pager using palette & taglines

## Colors
- Frame Black: #0F1115
- Paper White: #F7F8FA
- Signal Cyan: #28C1D1
- Echo Purple: #7A5CFA
- Grid Gray: #9AA3AF

Open `index.html` in a browser to preview. Edit colors in the `:root` CSS variables.
